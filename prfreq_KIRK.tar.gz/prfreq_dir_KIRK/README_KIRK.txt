Hi Christian and Diego,

I've been promising you both the version of PRFREQ that has my hack to
integrate the leptokurtic DFEs (including the gamma). Anyway, at long
last, that code is attached. It requires the GSL library to be installed.

To compile:

gcc -g  prfreq_additive_apr28_hack.c -lm   -o exec_fname_KEL_hack_good
-lgsl -lgslcblas


To run:

./exec_fname_KEL_hack_good
settings_chimp_sel_lnorm.2epoch.1st_grid.Pois2.txt
chimp_ns_sel_lnorm.out.2epoch.1st_grid.txt chimp_ns.obs_sfs.txt 
chimp_ns.2epoch.neut.exp_sfs.use.txt
>console.chimp.ns_sel_lnorm.2epoch.out.1st_grid.txt

where 

settings_chimp_sel_lnorm.2epoch.1st_grid.Pois2.txt is your settings file
(same as the regular PRFREQ, but using the "I" lines to do the
integration.

chimp_ns_sel_lnorm.out.2epoch.1st_grid.txt is oyour output file

chimp_ns.obs_sfs.txt is your input SFS for inference. If you're not doing
inference, but just generating SFSs (Diego, this is for you!), then you
don't need this.

chimp_ns.2epoch.neut.exp_sfs.use.txt is the neutral SFS for the
demographic model (both the size changes as well as the correct THETA) for
your model. You need to supply this to the program. It is input, not
output.

Please let me know if this isn't clear or if you have any problems running
it.


Best,

~Kirk

**********************************************
Kirk E. Lohmueller, PhD
Assistant Professor
Department of Ecology and Evolutionary Biology
University of California, Los Angeles
621 Charles E. Young Drive South
Los Angeles, CA 90095-1606

Office Phone: (310)-825-7636
Fax: (310)-206-0484
**********************************************