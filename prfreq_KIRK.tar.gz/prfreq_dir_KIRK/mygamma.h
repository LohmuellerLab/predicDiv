double gammln(double xx);					// returns ln[Gamma[xx]] for xx > 0

double factln(int n);					// returns ln(n!)

double bico(int n, int k);			// returns binomial coefficients (nCk)

