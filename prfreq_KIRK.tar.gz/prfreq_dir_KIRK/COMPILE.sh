gcc -O2 -g  prfreq_additive_apr28_hack.c -lm -o prfreq_KIRK -lgsl -lgslcblas
